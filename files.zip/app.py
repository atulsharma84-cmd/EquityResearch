"""
app.py — Nifty 500 swing trading dashboard (runs locally in your browser)
----------------------------------------------------------------------------
A single-file local web app. No data leaves your machine except the specific
stock text sent to the Anthropic API when you click "Analyze".

Requires:
    pip install flask pandas anthropic pypdf markdown

Run:
    py -3.14 app.py

Then open http://127.0.0.1:5000 in your browser.
"""

import os
import glob
import pandas as pd
from flask import Flask, request, render_template_string, send_file

import analyze_stock  # reuses gather_stock_data / analyze_symbol / PROMPT_TEMPLATE

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FUNDAMENTALS_PATH = os.path.join(BASE_DIR, "fundamentals", "fundamentals_master.csv")
ANALYSIS_DIR = os.path.join(BASE_DIR, "analysis")
CHARTS_DIR = os.path.join(BASE_DIR, "charts")
os.makedirs(ANALYSIS_DIR, exist_ok=True)

app = Flask(__name__)

BASE_HTML = """
<!doctype html>
<html>
<head>
<title>Nifty 500 Dashboard</title>
<style>
  body { font-family: -apple-system, Segoe UI, Arial, sans-serif; margin: 0; background: #f7f7f8; color: #1a1a1a; }
  header { background: #1a1a1a; color: white; padding: 16px 24px; }
  header a { color: white; text-decoration: none; margin-right: 20px; font-size: 14px; }
  header a:hover { text-decoration: underline; }
  .container { padding: 24px; max-width: 1100px; margin: 0 auto; }
  table { border-collapse: collapse; width: 100%; background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
  th, td { padding: 8px 12px; text-align: left; border-bottom: 1px solid #eee; font-size: 14px; }
  th { background: #fafafa; position: sticky; top: 0; }
  tr:hover { background: #f5f5f5; }
  .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }
  input[type=number] { width: 80px; padding: 4px; }
  label { display: inline-block; margin-right: 16px; font-size: 14px; }
  button, .btn { background: #d97757; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 14px; text-decoration: none; display: inline-block; }
  button:hover, .btn:hover { background: #c2663f; }
  .stat { display: inline-block; margin-right: 32px; }
  .stat .num { font-size: 28px; font-weight: bold; }
  .stat .label { font-size: 12px; color: #666; }
  .analyze-btn { background: #4a7c59; padding: 4px 10px; font-size: 12px; }
  img { max-width: 100%; border-radius: 6px; }
  pre { white-space: pre-wrap; }
</style>
</head>
<body>
<header>
  <a href="/">Dashboard</a>
  <a href="/reports">Analysis Reports</a>
</header>
<div class="container">
{{ content|safe }}
</div>
</body>
</html>
"""


def render(content):
    return render_template_string(BASE_HTML, content=content)


@app.route("/", methods=["GET"])
def dashboard():
    if not os.path.exists(FUNDAMENTALS_PATH):
        return render("<div class='card'><p>No fundamentals data found yet. Run "
                       "<code>py -3.14 run_pipeline.py</code> first.</p></div>")

    df = pd.read_csv(FUNDAMENTALS_PATH)

    # Filters from query params, with sensible defaults
    min_roe = float(request.args.get("min_roe", 15))
    max_de = float(request.args.get("max_de", 0.5))
    min_rev_growth = float(request.args.get("min_rev_growth", 10))
    min_profit_growth = float(request.args.get("min_profit_growth", 10))
    min_promoter = float(request.args.get("min_promoter", 40))
    max_pe = float(request.args.get("max_pe", 60))

    filtered = df[
        (df["roe_pct"].fillna(-999) >= min_roe)
        & (df["debt_to_equity"].fillna(999) <= max_de)
        & (df["revenue_growth_3yr_pct"].fillna(-999) >= min_rev_growth)
        & (df["profit_growth_3yr_pct"].fillna(-999) >= min_profit_growth)
        & (df["promoter_holding_pct"].fillna(-999) >= min_promoter)
        & (df["pe_ratio"].fillna(999) <= max_pe)
    ].sort_values("roe_pct", ascending=False)

    existing_reports = {f[:-len("_analysis.md")] for f in os.listdir(ANALYSIS_DIR)} if os.path.exists(ANALYSIS_DIR) else set()

    rows = ""
    for _, r in filtered.iterrows():
        sym = r["symbol"]
        has_report = sym in existing_reports
        action = (f'<a class="btn" style="padding:4px 10px;font-size:12px" href="/report/{sym}">View report</a>'
                  if has_report else
                  f'<button class="analyze-btn" onclick="analyzeStock(\'{sym}\')">Analyze</button>')
        rows += f"""<tr id="row-{sym}">
            <td><a href="/stock/{sym}">{sym}</a></td>
            <td>{r.get('roe_pct', '')}</td>
            <td>{r.get('debt_to_equity', '')}</td>
            <td>{r.get('revenue_growth_3yr_pct', '')}</td>
            <td>{r.get('profit_growth_3yr_pct', '')}</td>
            <td>{r.get('promoter_holding_pct', '')}</td>
            <td>{r.get('pe_ratio', '')}</td>
            <td id="action-{sym}">{action}</td>
        </tr>"""

    content = f"""
    <div class="card">
      <div class="stat"><div class="num">{len(df)}</div><div class="label">Total stocks with data</div></div>
      <div class="stat"><div class="num">{len(filtered)}</div><div class="label">Passing current filter</div></div>
      <div class="stat"><div class="num">{len(existing_reports)}</div><div class="label">Reports generated</div></div>
    </div>

    <div class="card">
      <form method="get">
        <label>Min ROE % <input type="number" step="0.1" name="min_roe" value="{min_roe}"></label>
        <label>Max D/E <input type="number" step="0.1" name="max_de" value="{max_de}"></label>
        <label>Min Revenue Growth % <input type="number" step="0.1" name="min_rev_growth" value="{min_rev_growth}"></label>
        <label>Min Profit Growth % <input type="number" step="0.1" name="min_profit_growth" value="{min_profit_growth}"></label>
        <label>Min Promoter Holding % <input type="number" step="0.1" name="min_promoter" value="{min_promoter}"></label>
        <label>Max P/E <input type="number" step="0.1" name="max_pe" value="{max_pe}"></label>
        <button type="submit">Apply filter</button>
      </form>
    </div>

    <div class="card">
      <table>
        <tr><th>Symbol</th><th>ROE %</th><th>D/E</th><th>Rev Growth %</th><th>Profit Growth %</th><th>Promoter %</th><th>P/E</th><th>Action</th></tr>
        {rows}
      </table>
    </div>

    <script>
    function analyzeStock(symbol) {{
        document.getElementById('action-' + symbol).innerHTML = 'Analyzing... (this can take 30-60s)';
        fetch('/analyze/' + symbol, {{ method: 'POST' }})
            .then(r => r.json())
            .then(data => {{
                if (data.success) {{
                    document.getElementById('action-' + symbol).innerHTML =
                        '<a class="btn" style="padding:4px 10px;font-size:12px" href="/report/' + symbol + '">View report</a>';
                }} else {{
                    document.getElementById('action-' + symbol).innerHTML = 'Failed: ' + data.error;
                }}
            }});
    }}
    </script>
    """
    return render(content)


@app.route("/analyze/<symbol>", methods=["POST"])
def analyze(symbol):
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return {"success": False, "error": "ANTHROPIC_API_KEY not set"}, 400
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)
        analyze_stock.analyze_symbol(symbol, client)
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}, 500


@app.route("/stock/<symbol>")
def stock_detail(symbol):
    chart_path = f"/chart/{symbol}"
    chart_exists = os.path.exists(os.path.join(CHARTS_DIR, f"{symbol}.png"))
    chart_html = f'<img src="{chart_path}">' if chart_exists else "<p>No chart found.</p>"

    df = pd.read_csv(FUNDAMENTALS_PATH)
    row = df[df["symbol"] == symbol]
    fundamentals_html = row.to_html(index=False) if not row.empty else "<p>No fundamentals row found.</p>"

    ar_dir = os.path.join(BASE_DIR, "annual_reports", symbol)
    ar_files = os.listdir(ar_dir) if os.path.isdir(ar_dir) else []
    cc_dir = os.path.join(BASE_DIR, "concall_transcripts", symbol)
    cc_files = os.listdir(cc_dir) if os.path.isdir(cc_dir) else []

    content = f"""
    <div class="card"><h2>{symbol}</h2>{chart_html}</div>
    <div class="card"><h3>Fundamentals</h3>{fundamentals_html}</div>
    <div class="card"><h3>Documents on file</h3>
      <p>Annual reports: {', '.join(ar_files) or 'none'}</p>
      <p>Concall transcripts: {', '.join(cc_files) or 'none'}</p>
    </div>
    <button onclick="fetch('/analyze/{symbol}', {{method:'POST'}}).then(r=>r.json()).then(d=>{{
        if(d.success) window.location='/report/{symbol}'; else alert('Failed: ' + d.error);
    }})">Run analysis</button>
    """
    return render(content)


@app.route("/chart/<symbol>")
def chart(symbol):
    path = os.path.join(CHARTS_DIR, f"{symbol}.png")
    if os.path.exists(path):
        return send_file(path)
    return "Not found", 404


@app.route("/reports")
def reports():
    if not os.path.exists(ANALYSIS_DIR):
        return render("<div class='card'><p>No reports generated yet.</p></div>")
    files = sorted(f for f in os.listdir(ANALYSIS_DIR) if f.endswith(".md"))
    rows = "".join(
        f'<li><a href="/report/{f[:-len("_analysis.md")]}">{f[:-len("_analysis.md")]}</a></li>'
        for f in files
    )
    content = f"<div class='card'><h2>Generated Reports ({len(files)})</h2><ul>{rows}</ul></div>"
    return render(content)


@app.route("/report/<symbol>")
def report(symbol):
    path = os.path.join(ANALYSIS_DIR, f"{symbol}_analysis.md")
    if not os.path.exists(path):
        return render(f"<div class='card'><p>No report for {symbol} yet.</p></div>")
    with open(path, encoding="utf-8") as f:
        text = f.read()
    try:
        import markdown
        html = markdown.markdown(text)
    except ImportError:
        html = f"<pre>{text}</pre>"
    content = f"<div class='card'>{html}</div>"
    return render(content)


if __name__ == "__main__":
    print("\nOpen http://127.0.0.1:5000 in your browser\n")
    app.run(debug=False, port=5000)
